using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using FancySignup.Models;
using FancySignup.Data;

namespace FancySignup.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccountController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Signup()
        {
            ViewBag.Countries = new SelectList(_context.Countries, "Id", "Name");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Signup(Users model)
        {
            if (ModelState.IsValid)
            {
                if (_context.Users.Any(u => u.Email == model.Email))
                {
                    ModelState.AddModelError("Email", "This email is already registered.");
                    ViewBag.Countries = new SelectList(_context.Countries, "Id", "Name");
                    return View(model);
                }

                _context.Users.Add(model);
                _context.SaveChanges();

                return RedirectToAction("SignupSuccess");
            }

            ViewBag.Countries = new SelectList(_context.Countries, "Id", "Name");
            return View(model);
        }

        [HttpGet]
        public IActionResult SignupSuccess()
        {
            return View();
        }
    }
}
